#include "BleCombo.h"

BleComboKeyboard Keyboard;
BleComboMouse Mouse(&Keyboard);
